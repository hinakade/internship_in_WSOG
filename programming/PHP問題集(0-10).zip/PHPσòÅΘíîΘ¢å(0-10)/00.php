<?php

// x=1
// y=1
// 上の２つを使い変数を利用して　TRUE　の条件式を作る。(5種類)
// 三項演算子(if・$bool?　　　 5+1 : $a.$b; 　&& || )
// 要は３つの指揮を使うもの。
// 上記２つだけの使用はできない。
// xとy以外を作ってはダ

echo '--------1つ目---------'.PHP_EOL;

$x =1;
$y =1;
switch ($x and $y) {
    

	case $x==1 and $y ==1:
		echo 'true';
		break;

	default:
	     echo'false';
		break;
}


echo "\n".'--------2つ目---------'.PHP_EOL;

if($x <=$y){
 echo'true';
}else{
	echo'false';
}


echo "\n".'--------3つ目---------'.PHP_EOL;

if($x === $y){
 echo'true';
}else{
	echo'false';
}


echo "\n".'--------4つ目---------'.PHP_EOL;

if($x or $y ==1){
 echo'true';
}else{
	echo'false';
}

echo "\n".'--------5つ目---------'.PHP_EOL;

if($x >= $y){
 echo'true';
}else{
	echo'false';
}

?>