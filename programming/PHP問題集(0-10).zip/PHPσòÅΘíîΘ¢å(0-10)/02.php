<?php
echo'-------問2-----------------------------'.PHP_EOL;

for ($j  = 1 ;$j  <  5;  $j++){

       for ($i  = 1 ;$i  <  6;  $i ++){
       
                echo '▪︎';
       }
             echo PHP_EOL;  
}

?>