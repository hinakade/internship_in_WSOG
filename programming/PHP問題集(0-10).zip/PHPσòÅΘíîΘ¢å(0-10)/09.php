<?php

echo'-------問9-----------------------------'.PHP_EOL;
$b=0;
for ($j  = 6 ;$j  >  1;  $j --){
 echo PHP_EOL;  


    for ($i  = 2 ;$i  <  $j;  $i ++){
       echo '1';
   }
 
    $b = $b +2;
    for ($i  = 1 ;$i  < $b;  $i ++){
        echo '▪︎';
   }
    for ($i  = 2 ;$i  <  $j;  $i ++){
                
        echo '1';
    }
}
    echo PHP_EOL;

$c =0;

for ($j  = 0 ;$j  <  4;  $j++){
    for ($i  = -1 ;$i  <  $j;  $i ++){
       
         echo '1';
    }
 
    $c = $c + 2;
  
     
    for ($i  = 9;$i  > $c;  $i--){

        echo '▪︎';
    }
              
  
    for ($i  = -1;$i  <  $j;  $i ++){
       
        echo '1';
    }
     echo PHP_EOL;  
}


?>
