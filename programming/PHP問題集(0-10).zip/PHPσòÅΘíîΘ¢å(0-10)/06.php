<?php

echo'-------問6-----------------------------'.PHP_EOL;

for ($j  = 1 ;$j  <  6;  $j++){

    for ($i  = 1 ;$i  <  $j;  $i ++){
       
        echo '1';
    }
  
    for ($i  = 6;$i  >  $j;  $i --){

        echo '▪︎';
    }
     echo PHP_EOL;  
}

?>
