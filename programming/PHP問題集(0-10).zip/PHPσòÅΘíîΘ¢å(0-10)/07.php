<?php
echo'-------問7-----------------------------'.PHP_EOL;
$b=0;
for ($j  = 6 ;$j  >  1;  $j --){

  for ($i  = 2 ;$i  <  $j;  $i ++){
       echo '1';
   }
 
       $b = $b +2;
  
         for ($i  = 1 ;$i  < $b;  $i ++){
       
              echo '▪︎';
       }
  
         for ($i  = 2 ;$i  <  $j;  $i ++){
                
              echo '1';
        }
        echo PHP_EOL;
}
?>