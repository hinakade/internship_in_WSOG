<?php
echo'-------問1-----------------------------'.PHP_EOL;

echo '▪︎';
echo '▪︎';
echo '▪︎';
echo '▪︎';
echo '▪︎'.PHP_EOL;


echo '▪︎';
echo '▪︎';
echo '▪︎';
echo '▪︎';
echo '▪︎'.PHP_EOL;


echo '▪︎';
echo '▪︎';
echo '▪︎';
echo '▪︎';
echo '▪︎'.PHP_EOL;


echo '▪︎';
echo '▪︎';
echo '▪︎';
echo '▪︎';
echo '▪︎'.PHP_EOL;
?>