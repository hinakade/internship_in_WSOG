<?php
echo'-------問8----------------------------'.PHP_EOL;

$c =0;

for ($j  = 1 ;$j  <  6;  $j++){
    for ($i  = 1 ;$i  <  $j;  $i ++){
       
         echo '1';
    }
 
    $c = $c + 2;
  
     
    for ($i  = 11;$i  > $c;  $i--){

        echo '▪︎';
    }
              
  
    for ($i  = 1 ;$i  <  $j;  $i ++){
       
        echo '1';
    }
     echo PHP_EOL;  
}


?>