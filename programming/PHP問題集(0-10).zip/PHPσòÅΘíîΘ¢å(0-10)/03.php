<?php
echo'-------問３-----------------------------'.PHP_EOL;

for ($j  = 1 ;$j  <  7;  $j++){

       for ($i  = 1 ;$i  <  $j;  $i ++){
       
                echo '▪︎';
       }
             echo PHP_EOL; 
}
?>