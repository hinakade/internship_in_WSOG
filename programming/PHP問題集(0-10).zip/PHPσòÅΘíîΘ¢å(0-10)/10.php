<?php
echo'-------問10-----------------------------'.PHP_EOL;

//1から10をループ文を作成する。(5種類)

echo '-- 1つ目 --'.PHP_EOL;
// for

for($i=1 ; $i<=100  ; $i++){
  
  echo $i;
echo PHP_EOL;  

  
}

echo '-- 2つ目 --'.PHP_EOL;
// while
$a =0;
while ($a <100){
  
  ++$a;
 
  echo $a;
echo PHP_EOL;  

  
}


echo '-- 3つ目 --'.PHP_EOL;  

  // foreach
  foreach(range(1,100) as $b){
      
       echo $b;
     echo PHP_EOL;  
}

echo '-- 4つ目 --'.PHP_EOL;  
//漸化式と制限演算

class NaturalNumberIterator implements Iterator
{
    private $i = 1;
    function current() { return $this->i; }
    function key()     { return $this->i; }
    function next()    { ++$this->i; }
    function rewind()  { $this->i = 1; }
    function valid()   { return true; }
}

$it = new NaturalNumberIterator;
$it = new LimitIterator($it, 0, 100);

foreach ($it as $i) {
    echo $i, PHP_EOL;
}



echo '-- 5つ目 --'.PHP_EOL;
// range()　を使う
echo implode(PHP_EOL, range(1, 100));

?>