<?php
echo'-------問4------------------------'.PHP_EOL;

for ($j  = 6 ;$j  >  1;  $j --){

       for ($i  = 1 ;$i  <  $j;  $i ++){
       
                echo '▪︎';
       }
            echo PHP_EOL;  
}
?>