<?php
echo'-------問5-----------------------------'.PHP_EOL;

for ($j  = 5 ;$j  >  0;  $j --){
        
    for ($i  = 1 ;$i  <  $j;  $i ++){

         echo'1';
    }
       

    for ($i  = 6;$i  >  $j;  $i --){

         echo '▪︎';
    }
         
      echo PHP_EOL;  
}

?>